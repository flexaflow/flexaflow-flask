"""Demo Thing: see docs/EXTENSIONS.md in FlexaFlow for everything register(api) can do."""


def register(api):
	@api.route("/demo-thing/")
	def home():
		return api.render("home.html", page={"title": "Demo Thing"})

	@api.admin_route("/", capability="manage_settings")
	def admin_home():
		return api.render("admin.html")

	api.add_admin_menu("Demo Thing", [{"label": "Overview", "url": "/admin/ext/demo-thing/"}],
	                   capability="manage_settings")
